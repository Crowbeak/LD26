import pyglet

class Score(object):
    def __init__(self):
        self.eyes_poked = 0
        self.timer = 2500